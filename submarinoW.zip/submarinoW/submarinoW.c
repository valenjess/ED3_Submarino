/**
 * @file main.c
 * @brief Sistema de control para 3 motores con protección por interrupciones.
 * @author Gemini Thought Partner
 * @date 2025-12-14
 * * Este programa controla dos motores unidireccionales y un motor bidireccional
 * utilizando un driver L293D. Emplea polling para señales de control y
 * GPIO Interrupts para los finales de carrera del Motor 3.
 */

#include "pico/stdlib.h"
#include "hardware/gpio.h"

/** @name Pines de Control (Polling) */
///@{
#define PIN_RELE_M1     14  ///< Activación Motor 1
#define PIN_RELE_M2     15  ///< Activación Motor 2
#define PIN_RELE_M3_FWD 22  ///< Mando avance Motor 3
#define PIN_RELE_M3_BWD 21  ///< Mando retroceso Motor 3
///@}

/** @name Pines de Seguridad (Interrupciones) */
///@{
#define PIN_LIMIT_FWD   12  ///< Sensor límite adelante
#define PIN_LIMIT_BWD   13  ///< Sensor límite atrás
///@}

/** @name Salidas hacia L293D */
///@{
#define M1_PWM_EN       0   ///< Enable Motor 1 (PWM)
#define M1_CONTROL      1   ///< Control Motor 1
#define M2_CONTROL      2   ///< Control Motor 2
#define M2_DIG_EN       3   ///< Enable Motor 2 (Digital)
#define M3_ENABLE       7   ///< Enable Motor 3
#define M3_IN_A         8   ///< Entrada A Puente H Motor 3
#define M3_IN_B         9   ///< Entrada B Puente H Motor 3
///@}

/**
 * @brief Variables globales volátiles para estado de límites.
 * Se marcan como 'volatile' porque cambian dentro de una interrupción.
 */
volatile bool limit_fwd_hit = false;
volatile bool limit_bwd_hit = false;

/**
 * @brief Manejador de interrupciones (ISR) para los finales de carrera.
 * * Se ejecuta inmediatamente cuando un microsuiche cambia de estado.
 * @param gpio El pin que generó la interrupción.
 * @param events El tipo de evento (flanco de subida/bajada).
 */
void gpio_callback(uint gpio, uint32_t events) {
    if (gpio == PIN_LIMIT_FWD) {
        // Si el pin lee 0 (GND), el límite fue alcanzado
        limit_fwd_hit = !gpio_get(PIN_LIMIT_FWD);
        if (limit_fwd_hit) gpio_put(M3_ENABLE, 0); // Parada de emergencia
    }
    if (gpio == PIN_LIMIT_BWD) {
        limit_bwd_hit = !gpio_get(PIN_LIMIT_BWD);
        if (limit_bwd_hit) gpio_put(M3_ENABLE, 0); // Parada de emergencia
    }
}

/**
 * @brief Inicialización de hardware y periféricos.
 */
void setup() {
    stdio_init_all();

    // 1. Configurar Entradas de Relés 
    uint inputs[] = {PIN_RELE_M1, PIN_RELE_M2, PIN_RELE_M3_FWD, PIN_RELE_M3_BWD};
    for (int i = 0; i < 4; i++) {
        gpio_init(inputs[i]);
        gpio_set_dir(inputs[i], GPIO_IN);
        gpio_pull_down(inputs[i]); 
    }

    // 2. Configurar Microsuiches (Interrupciones)
    gpio_init(PIN_LIMIT_FWD);
    gpio_set_dir(PIN_LIMIT_FWD, GPIO_IN);
    gpio_pull_up(PIN_LIMIT_FWD); // Resistencia Pull-up para cierre a GND

    gpio_init(PIN_LIMIT_BWD);
    gpio_set_dir(PIN_LIMIT_BWD, GPIO_IN);
    gpio_pull_up(PIN_LIMIT_BWD);

    // Configurar el callback de interrupción para ambos límites
    gpio_set_irq_enabled_with_callback(PIN_LIMIT_FWD, GPIO_IRQ_EDGE_FALL | GPIO_IRQ_EDGE_RISE, true, &gpio_callback);
    gpio_set_irq_enabled(PIN_LIMIT_BWD, GPIO_IRQ_EDGE_FALL | GPIO_IRQ_EDGE_RISE, true);

    // 3. Configurar Salidas Digitales (L293D)
    uint outputs[] = {M1_CONTROL, M2_CONTROL, M2_DIG_EN, M3_ENABLE, M3_IN_A, M3_IN_B, M1_PWM_EN};
    for (int i = 0; i < 7; i++) {
        gpio_init(outputs[i]);
        gpio_set_dir(outputs[i], GPIO_OUT);
        gpio_put(outputs[i], 0);
    }

    // 4. Inicializar estados iniciales de banderas
    limit_fwd_hit = !gpio_get(PIN_LIMIT_FWD);
    limit_bwd_hit = !gpio_get(PIN_LIMIT_BWD);
}

/**
 * @brief Bucle principal de ejecución (Polling).
 */
int main() {
    setup();

    while (true) {
        // --- LÓGICA MOTORES 1 Y 2 (POLLING) ---
        bool s1 = gpio_get(PIN_RELE_M1);
        bool s2 = gpio_get(PIN_RELE_M2);

        // Control Motor 1
        if (s1) {
            gpio_put(M1_PWM_EN, 1);
            gpio_put(M1_CONTROL, 1);
        } else {
            gpio_put(M1_PWM_EN, 0);
            gpio_put(M1_CONTROL, 0);
        }

        // Control Motor 2
        if (s2) {
            gpio_put(M2_CONTROL, 1);
            gpio_put(M2_DIG_EN, 1);
        } else {
            gpio_put(M2_CONTROL, 0);
            gpio_put(M2_DIG_EN, 0);
        }

        // --- LÓGICA MOTOR 3 (POLLING + FILTRO DE INTERRUPCIÓN) ---
        bool m3_fwd_req = gpio_get(PIN_RELE_M3_FWD);
        bool m3_bwd_req = gpio_get(PIN_RELE_M3_BWD);

        if (m3_fwd_req && !limit_fwd_hit) {
            gpio_put(M3_IN_A, 1);
            gpio_put(M3_IN_B, 0);
            gpio_put(M3_ENABLE, 1);
        } 
        else if (m3_bwd_req && !limit_bwd_hit) {
            gpio_put(M3_IN_A, 0);
            gpio_put(M3_IN_B, 1);
            gpio_put(M3_ENABLE, 1);
        } 
        else {
            // Detención si no hay pulso o si el límite está activo
            gpio_put(M3_ENABLE, 0);
            gpio_put(M3_IN_A, 0);
            gpio_put(M3_IN_B, 0);
        }

        sleep_ms(10); // Estabilidad del bucle
    }
}