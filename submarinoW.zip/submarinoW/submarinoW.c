/**
 * @file submarinoW.c
 * @brief Sistema de control de 3 motores con bajo consumo y gestión total por IRQ, el cual permite 
 * la implementación de un sistema submarino.
 * @date 2025-12-14
 */

#include "pico/stdlib.h"
#include "hardware/gpio.h"
#include "hardware/sync.h" //para __wfi()

// --- DEFINICIÓN DE PINES ---
#define PIN_RELE_M1     14
#define PIN_RELE_M2     15
#define PIN_RELE_M3_FWD 22
#define PIN_RELE_M3_BWD 21
#define PIN_LIMIT_FWD   12
#define PIN_LIMIT_BWD   13

#define M1_PWM_EN       0
#define M1_CONTROL      1
#define M2_CONTROL      2
#define M2_DIG_EN       3
#define M3_ENABLE       7
#define M3_IN_A         8
#define M3_IN_B         9

// Variables de estado protegidas para el Motor 3
volatile bool limit_fwd_hit = false;
volatile bool limit_bwd_hit = false;

/**
 * @brief Manejador de interrupciones para TODAS las entradas.
 * Cualquier cambio en relés o límites despertará a la CPU.
 */
void gpio_callback(uint gpio, uint32_t events) {
    // Actualización inmediata de seguridad para Motor 3
    if (gpio == PIN_LIMIT_FWD) {
        limit_fwd_hit = !gpio_get(PIN_LIMIT_FWD);
        if (limit_fwd_hit) gpio_put(M3_IN_A, 0); 
    }
    if (gpio == PIN_LIMIT_BWD) {
        limit_bwd_hit = !gpio_get(PIN_LIMIT_BWD);
        if (limit_bwd_hit) gpio_put(M3_IN_B, 0);
    }
    
    // Para los relés (14, 15, 21, 22), no necesitamos lógica extra aquí.
    // El simple hecho de que ocurra la IRQ despertará al main loop del __wfi().
}


int main() {
    // 1. Configurar Relés e Interrupciones asociadas
    uint relay_inputs[] = {PIN_RELE_M1, PIN_RELE_M2, PIN_RELE_M3_FWD, PIN_RELE_M3_BWD};
    for (int i = 0; i < 4; i++) {
        gpio_init(relay_inputs[i]);
        gpio_set_dir(relay_inputs[i], GPIO_IN);
        gpio_pull_down(relay_inputs[i]);
        // Activamos IRQ en ambos flancos (presionar y soltar)
        gpio_set_irq_enabled_with_callback(relay_inputs[i], GPIO_IRQ_EDGE_RISE | GPIO_IRQ_EDGE_FALL, true, &gpio_callback);
    }

    // 2. Configurar Microsuiches e Interrupciones
    uint limit_inputs[] = {PIN_LIMIT_FWD, PIN_LIMIT_BWD};
    for (int i = 0; i < 2; i++) {
        gpio_init(limit_inputs[i]);
        gpio_set_dir(limit_inputs[i], GPIO_IN);
        gpio_pull_up(limit_inputs[i]);
        gpio_set_irq_enabled(limit_inputs[i], GPIO_IRQ_EDGE_RISE | GPIO_IRQ_EDGE_FALL, true);
    }

    // 3. Configurar Salidas L293D
    uint outputs[] = {M1_CONTROL, M2_CONTROL, M2_DIG_EN, M3_ENABLE, M3_IN_A, M3_IN_B, M1_PWM_EN};
    for (int i = 0; i < 7; i++) {
        gpio_init(outputs[i]);
        gpio_set_dir(outputs[i], GPIO_OUT);
        gpio_put(outputs[i], 0);
    }

    limit_fwd_hit = !gpio_get(PIN_LIMIT_FWD);
    limit_bwd_hit = !gpio_get(PIN_LIMIT_BWD);

    while (true) {
        // --- PROCESAMIENTO DE ESTADOS (WAKE UP) ---
        
        // Motor 1
        bool s1 = gpio_get(PIN_RELE_M1);
        gpio_put(M1_PWM_EN, s1);
        gpio_put(M1_CONTROL, s1);

        // Motor 2
        bool s2 = gpio_get(PIN_RELE_M2);
        gpio_put(M2_DIG_EN, s2);
        gpio_put(M2_CONTROL, s2);

        // Motor 3 con validación de límites
        bool m3_fwd = gpio_get(PIN_RELE_M3_FWD);
        bool m3_bwd = gpio_get(PIN_RELE_M3_BWD);

        if (m3_fwd && !limit_fwd_hit) {
            gpio_put(M3_IN_A, 1);
            gpio_put(M3_IN_B, 0);
            gpio_put(M3_ENABLE, 1);
        } 
        else if (m3_bwd && !limit_bwd_hit) {
            gpio_put(M3_IN_A, 0);
            gpio_put(M3_IN_B, 1);
            gpio_put(M3_ENABLE, 1);
        } 
        else {
            gpio_put(M3_ENABLE, 0);
            gpio_put(M3_IN_A, 0);
            gpio_put(M3_IN_B, 0);
        }

        /**
         * @brief MODO BAJO CONSUMO
         * Esta instrucción detiene el reloj del núcleo del procesador.
         * La CPU se quedará aquí "congelada" sin consumir energía hasta que 
         * una interrupción de cualquier pin ocurra.
         */
        __wfi(); 
    }
}